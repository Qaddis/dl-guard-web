// Импорт "express" и создание сервера
const express = require("express");
const app = express();
const port = 4444;

// Добавление возможности POST-запросов
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

// Раздача статики
app.use(express.static("public"));

// Импорт "handlebars" и настройка шаблонизатора
const hbs = require("hbs");
app.set("views", "views");
app.set("view engine", "hbs");

// Импорт "mongoose" и соединение с базой данных
const mongoose = require("mongoose");
mongoose.connect("ваша ссылка на бд"); // Внимание! В кавычки вы должны ввести ссылку на свою базу данных

// Создание схем
const studentsSchema = new mongoose.Schema({
	firstname: {
		required: true,
		type: String,
	},
	surname: {
		required: true,
		type: String,
	},
	uid: {
		unique: true,
		required: true,
		type: String,
	},
	login: {
		unique: true,
		required: true,
		type: String,
	},
	password: {
		required: true,
		type: String,
	},
	isStudying: {
		required: true,
		type: Boolean,
	},
});

const statsSchema = new mongoose.Schema({
	date: {
		required: true,
		type: Date,
	},
	systemErrors: [
		{
			errType: String,
		},
	],
	visitors: [
		{
			student: mongoose.Schema.Types.ObjectId,
			time: Date,
		},
	],
});

// Соединение схем с коллекциями
const Student = mongoose.model("students", studentsSchema);
const Stat = mongoose.model("stats", statsSchema);

// Запуск сервера
app.listen(port, () => {
	console.log(`Сервер запущен по адресу: http://localhost:${port}/`);
});

// Роуты
app.get("/", async (req, res) => {
	let today = new Date();
	today.setHours(8, 30, 0, 0);
	today = today.toISOString();

	let statData = await Stat.aggregate([
		{
			$addFields: {
				todayDate: {
					$toDate: today,
				},
			},
		},
		{
			$match: {
				$expr: { $eq: ["$date", "$todayDate"] },
			},
		},
		{
			$project: {
				_id: 0,
				visitors: {
					$reduce: {
						input: "$visitors",
						initialValue: [0, 0],
						in: {
							$cond: [
								{
									$lt: ["$$this.time", "$date"],
								},
								[
									{
										$add: [
											{
												$arrayElemAt: ["$$value", 0],
											},
											1,
										],
									},
									{
										$arrayElemAt: ["$$value", 1],
									},
								],
								[
									{
										$arrayElemAt: ["$$value", 0],
									},
									{
										$add: [
											{
												$arrayElemAt: ["$$value", 1],
											},
											1,
										],
									},
								],
							],
						},
					},
				},
				glitches: {
					$map: {
						input: ["device", "server", "program"],
						as: "type",
						in: {
							$size: {
								$filter: {
									input: "$systemErrors",
									cond: {
										$eq: ["$$this.errType", "$$type"],
									},
								},
							},
						},
					},
				},
			},
		},
	]);

	res.render("stat", {
		haveData: statData != [],
		visitors: statData[0].visitors,
		glitches: statData[0].glitches,
	});
});

app.post("/check-uid", async (req, res) => {
	const uid = req.body.uid;

	try {
		const student = await Student.findOne({ uid: uid });

		if (student) {
			if (student.isStudying) {
				res.send("true");

				detectStudent(student._id);
			} else {
				res.send("false");
			}
		} else {
			res.send("false");
		}
	} catch (error) {
		res.send("error");
		console.error(error);
	}
});

app.get("/glitch-detected", (req) => {
	detectGlitch(req.body.type);
});

// Функции
async function detectGlitch(type) {
	let today = new Date();
	today.setHours(8, 30, 0, 0);
	today = today.toISOString();

	const todayStat = await Stat.findOne({ date: today });

	if (todayStat) {
		todayStat.systemErrors.push({ errType: type });

		try {
			await todayStat.save();
		} catch (error) {
			console.error(error);
		}
	} else {
		const newStat = new Stat({
			date: today,
			systemErrors: [{ errType: type }],
			visitors: [],
		});

		try {
			await newStat.save();
		} catch (error) {
			console.error(error);
		}
	}
}

async function detectStudent(student) {
	let today = new Date();
	today.setHours(8, 30, 0, 0);
	today = today.toISOString();

	const todayStat = await Stat.findOne({ date: today });
	const timeNow = new Date();

	if (todayStat) {
		todayStat.visitors.push({ student: student, time: timeNow.toISOString() });

		try {
			await todayStat.save();
		} catch (error) {
			console.error(error);
		}
	} else {
		const newStat = new Stat({
			date: today,
			systemErrors: [],
			visitors: [{ student: student, time: timeNow.toISOString() }],
		});

		try {
			await newStat.save();
		} catch (error) {
			console.error(error);
		}
	}
}
