// Подключение express и создание сервера
const express = require("express");
const app = express();
const port = 4444;

// Добавляем возможность POST-запросов
app.use(express.urlencoded({ extended: true }));

// Подключаем статику
app.use(express.static("public"));

// Подключение к БД
const mongoose = require("mongoose");
mongoose.connect("введите ссылку к бд");

// Создание схем
const studentsSchema = new mongoose.Schema(
	{
		firstname: {
			required: true,
			type: String,
		},
		surname: {
			required: true,
			type: String,
		},
		uid: {
			unique: true,
			required: true,
			type: String,
		},
		login: {
			unique: true,
			required: true,
			type: String,
		},
		password: {
			required: true,
			type: String,
		},
		isStudying: {
			required: true,
			type: Boolean,
		},
	},
	{
		timestamps: true,
	}
);

// Соединяем схему с коллекцией
const Student = mongoose.model("название коллекции", studentsSchema);
// const Employee = mongoose.model('employees', employeesSchema);

// Запуск сервера
app.listen(port, function () {
	console.log(`Сервер запущен по адресу: http://localhost:${port}/`);
});

// Сервисная часть
app.get("/check-uid", async function (req, res) {
	const uid = req.query.uid;

	try {
		let student = await Student.findOne({ uid: uid });

		if (student) {
			if (student.isStudying) {
				res.send("true");
			} else {
				res.send("false");
			}
		} else {
			res.send("false");
		}
	} catch (error) {
		res.send("error");
		console.log(error);
	}
});

app.get("/log-error", async function (req, res) {
	const { type } = req.query;
});

// Мобильное приложение
app.post("/set-uid", async function (req, res) {
	const { login, password } = req.body;

	try {
		let student = await Student.findOne({ login: login });

		if (student) {
			if (student.password == password) {
				res.send(student);
			} else {
				res.send("error");
			}
		} else {
			res.send("error");
		}
	} catch (error) {
		res.send("error");
	}
});
